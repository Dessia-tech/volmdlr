#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb 28 11:05:28 2020

@author: masfaraud
"""


from .core import point3D_instanciator